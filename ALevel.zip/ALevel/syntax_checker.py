#This program was written by Nicole Rasmussen.
# It is a syntax checker for Java
import syntax_checker_lib as sc
import re

def main():
    file= open("ALevel.txt","r")
    #read in file
    a_code = file.read()
    #remove comments
    a_code = sc.remove_comments(a_code)
    #remove imports
    a_code = sc.remove_imports(a_code)
    #remove newlines
    a_code = a_code.strip("\n")
    #remove other whitespace
    a_code = re.sub("\s+", "",a_code)
    # verify main method is written correctly
    a_code = sc.verify_main_method(a_code)
    #verify scanner
    a_code = sc.verify_scanner(a_code)
    #verify declarations of identifiers are written correctly
    a_code = sc.verify_indentifier_declarations(a_code)
    #check assignment statements are correct
    a_code = sc.verify_assignment_statement(a_code)
    #check arithmetic statements are correct
    a_code = sc.verify_arithmetic_statement(a_code)
    #check simple output methods are correct
    a_code = sc.verify_output_methods(a_code)
    #check more complex output methods are correct
    a_code = sc.verify_complex_output_methods(a_code)
    #check while loop is correct
    a_code = sc.verify_while_loop(a_code)
    #check if/else conditionals are correct
    a_code = sc.verify_conditionals(a_code)
    #verify Object declarations
    a_code = sc.verify_object_declarations(a_code)
    #verify Object method calls
    a_code = sc.verify_object_method_call(a_code)
    #verify class constructor
    a_code = sc.verify_constructor(a_code)
    #verify method
    a_code = sc.verify_method(a_code)
    #verify class
    a_code = sc.verify_class(a_code)
    if(re.search(r"\w+",a_code)):
        print("You have errors that prevent your code from compiling:")
        print(a_code)
    else:
        print("Your code compiled!")

main()

