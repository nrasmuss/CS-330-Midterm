import re

#method to remove comments
def remove_comments(file):
    pattern1 = r"//.+\n" #pattern for single line comment
    pattern2 = r"/\*([\s\S]*?)\*/" #pattern for multi-line comment
    file = re.sub(pattern1, "\n", file)
    file = re.sub(pattern2, "\n",file)
    return file

#method to remove imports
def remove_imports(file):
    pattern1 = "import\s.+;" #pattern for import statements
    file = re.sub(pattern1, "", file)
    return file

def verify_class(file):
    pattern1 = r"class[A-Z]\w*\{\}"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,r"",file)
    pattern2 = r"class[A-Z]\w*\{(.+)\}"
    print(file)
    if(re.search(pattern2,file)):
        file = re.sub(pattern2,r"\1",file)
    return file

def verify_main_method(file):
    pattern1 = r"publicstaticvoidmain\(String\[\]args\)\{(.+;)\}\}\b"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,r"\1}",file)
    return file

def verify_indentifier_declarations(file):
    pattern1 = "String[a-z]\w+;|boolean[a-z]\w+;|int[a-z]\w+;|char[a-z]\w+;|double[a-z]\w+;|float[a-z]\w+;"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1, "", file)
    return file

def verify_assignment_statement(file):
    proof_of_left = verify_left_side(file)
    if(proof_of_left):
        file = verify_right_side(file)
    return file

def verify_left_side(file):
    pattern1 = r"(String|boolean|int|char|double|float)[a-z]\w+="
    if(re.search(pattern1,file)):
        return True
    else:
        return False

def verify_right_side(file):
    pattern1 = r"String[a-z]\w*=\"\w*\";|String[a-z]\w*=\"\w+\"\+\w\+\"\w+\";|int[a-z]\w*=\d+;|boolean[a-z]\w*=\w+;"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,"",file)
    return file

def verify_arithmetic_statement(file):
    pattern1 = ";[a-z]\w*=[a-z]*\w*(\+|-|\*|\/|%)(\d+|\w+);"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,";",file)
    return file

def verify_output_methods(file):
    pattern1 = r"System\.out\.println\(\"?\w+\"?\);"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,"",file)
    return file

def verify_complex_output_methods(file):
    pattern1 = r"System\.out\.println\(\"?\w+<?>?=?\d+\"\);"
    if (re.search(pattern1, file)):
        file = re.sub(pattern1, "", file)
    pattern2 = r"System\.out\.printl?n?\(\"?\w+\"?\+[a-z]\w*\+?\"?\w*\"?\+?[a-z]*\w*\+?\"?\w*\.?\"?\);"
    if(re.search(pattern2, file)):
        file = re.sub(pattern2,"",file)
    return file

def verify_while_loop(file):
    pattern1 = r"while\((\w+\=?\d*)?((\;[a-z](\<|\>|\<\=)\d+\;)|([a-z](\<|\>|\<\=)\d+))([a-z]\w*((\+\+)|(\-\-)))?\)\{\}"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,"",file)
    return file

def verify_conditionals(file):
    pattern1 = r"if\(\w+<\d+\)\{\}"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,"",file)
    pattern2 = r"else\{\}"
    if(re.search(pattern2,file)):
        file = re.sub(pattern2,"",file)
    return file

def verify_scanner(file):
    pattern1 = r"Scanner\w+=newScanner\(System\.in\);System\.out\.println\(\"\w+\??\"\);"
    if(re.search(pattern1, file)):
        file = re.sub(pattern1,"",file)
        pattern2 = r"String\w+=\w+\.next\(\);System\.out\.println\(\"\w+\??\"\);"
        if(re.search(pattern2,file)):
            file = re.sub(pattern2, "", file)
            if(re.search("intnewInt=sc\.nextInt\(\);",file)):
                file = re.sub("intnewInt=sc\.nextInt\(\);", "",file)
    return file

def verify_object_declarations(file):
    pattern1 = r"[A-Z]\w+=new[A-Z]\w+\(\w+\,?\w*\);"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,"",file)
    return file

def verify_object_method_call(file):
    pattern1 = r"\w+\.[a-z][a-z0-9]+[A-Z]?[a-z0-9]+\(\);"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,"",file)
    return file

def verify_constructor(file):
    pattern1 = r"\b(public|private|protected)?[A-Z]\w+\(([A-Za-z]\w+\,*)*\)\{([a-z]\w+=\"?\w+\"?;)*\}"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,"",file)
    return file

def verify_method(file):
    pattern1 = r"(public|private|protected)?(void|[A-Za-z]*)[a-z]+[a-z]*[A-Z]?\w+\(([A-Za-z]\w+\,*)*\)\{\}"
    if(re.search(pattern1,file)):
        file = re.sub(pattern1,"",file)
    return file
